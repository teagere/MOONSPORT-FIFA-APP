# Visual Prompt Studio

An original Manifest V3 Chrome extension that captures a reference image and prepares a detailed instruction prompt to paste into ChatGPT alongside that image.

It does **not** call the OpenAI API, does not require an API key, and creates no separate API charges.

## Workflow

1. Right-click a visible web image and choose **Analyse image with Visual Prompt Studio**, draw a custom page region, or upload an image from your Mac.
2. Add optional creative direction such as “focus on the lighting and editorial colour grade”.
3. Click **Prepare & copy ChatGPT prompt**.
4. Open ChatGPT, upload the same reference image, paste the copied instruction, and send it.

The prepared instruction asks ChatGPT to analyse:

- subject and action
- composition and focal hierarchy
- style and medium
- lighting
- colour palette
- materials and texture
- camera and lens character
- environment and mood
- typography and graphic elements
- a polished reusable generation prompt
- an optional negative prompt

## Install on Chrome for Mac

1. Open `chrome://extensions`.
2. Turn on **Developer mode** in the top-right corner.
3. Click **Load unpacked**.
4. Select this `image-prompt-studio-extension` folder.
5. Pin **Visual Prompt Studio** from Chrome's Extensions menu.

If version 1.0 was already loaded, click its **Reload** button on `chrome://extensions` after replacing the files.

Chrome does not allow extensions to run on internal pages such as `chrome://` or on the Chrome Web Store itself. Test it on a normal website.

## Privacy

The extension has no API key, account system, analytics, advertising, remote server, or external host access. Captured images and up to 20 prepared instructions are stored only in `chrome.storage.local` inside the current Chrome profile.

Permissions are used as follows:

- `activeTab`, `scripting`, and `tabs`: capture the visible image or page region you explicitly select, and open ChatGPT when requested.
- `contextMenus`: add the right-click actions.
- `sidePanel`: show the extension workspace.
- `storage` and `unlimitedStorage`: keep temporary captures and local history.

## Browser limits

- Right-click capture records the visible pixels of an image. If it is partly off-screen, only the visible portion is captured.
- Browser-protected pages cannot be captured.
- Unpacked extensions are local development installs. Chrome may periodically remind you that developer-mode extensions are enabled.
