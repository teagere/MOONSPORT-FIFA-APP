const MENU_ANALYZE = "visual-prompt-analyze-image";
const MENU_CAPTURE = "visual-prompt-capture-region";

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: MENU_ANALYZE,
      title: "Prepare ChatGPT prompt from this image",
      contexts: ["image"]
    });
    chrome.contextMenus.create({
      id: MENU_CAPTURE,
      title: "Capture area for a ChatGPT prompt",
      contexts: ["page"]
    });
  });
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
});

chrome.action.onClicked.addListener(async (tab) => {
  if (tab.windowId) await openPanel(tab.windowId);
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (!tab?.id || !tab.windowId) return;

  if (info.menuItemId === MENU_ANALYZE) {
    await captureImageElement(tab, info.srcUrl || "");
  }

  if (info.menuItemId === MENU_CAPTURE) {
    await startRegionCapture(tab.id);
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "START_REGION_CAPTURE") {
    chrome.tabs.query({ active: true, currentWindow: true }).then(async ([tab]) => {
      if (!tab?.id) throw new Error("No active tab found.");
      await startRegionCapture(tab.id);
      sendResponse({ ok: true });
    }).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }

  if (message?.type === "REGION_SELECTED" && sender.tab?.windowId) {
    captureSelectedRegion(sender.tab.windowId, message.bounds)
      .then(() => sendResponse({ ok: true }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
});

async function captureImageElement(tab, srcUrl) {
  try {
    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: locateImage,
      args: [srcUrl]
    });

    if (!result?.bounds) throw new Error("The selected image is not currently visible.");
    const screenshotDataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: "png" });
    await setPendingCapture({
      kind: "crop",
      dataUrl: screenshotDataUrl,
      bounds: result.bounds,
      sourceUrl: tab.url || "",
      capturedAt: Date.now()
    });
    await openPanel(tab.windowId);
  } catch (error) {
    await setPendingCapture({ kind: "error", error: readableError(error), capturedAt: Date.now() });
    await openPanel(tab.windowId);
  }
}

function locateImage(srcUrl) {
  const images = [...document.images];
  const normalized = (value) => {
    try { return new URL(value, location.href).href; } catch { return value; }
  };
  const wanted = normalized(srcUrl);
  const exact = images.find((image) => normalized(image.currentSrc || image.src) === wanted);
  const element = exact || images
    .filter((image) => {
      const rect = image.getBoundingClientRect();
      return rect.width > 30 && rect.height > 30 && rect.bottom > 0 && rect.top < innerHeight;
    })
    .sort((a, b) => {
      const ar = a.getBoundingClientRect();
      const br = b.getBoundingClientRect();
      return (br.width * br.height) - (ar.width * ar.height);
    })[0];

  if (!element) return null;
  const rect = element.getBoundingClientRect();
  const left = Math.max(0, rect.left);
  const top = Math.max(0, rect.top);
  const right = Math.min(innerWidth, rect.right);
  const bottom = Math.min(innerHeight, rect.bottom);
  if (right <= left || bottom <= top) return null;

  return {
    bounds: {
      x: left,
      y: top,
      width: right - left,
      height: bottom - top,
      viewportWidth: innerWidth,
      viewportHeight: innerHeight
    }
  };
}

async function startRegionCapture(tabId) {
  try {
    await chrome.scripting.executeScript({ target: { tabId }, files: ["region-capture.js"] });
  } catch (error) {
    const tab = await chrome.tabs.get(tabId);
    await setPendingCapture({ kind: "error", error: readableError(error), capturedAt: Date.now() });
    if (tab.windowId) await openPanel(tab.windowId);
  }
}

async function captureSelectedRegion(windowId, bounds) {
  const screenshotDataUrl = await chrome.tabs.captureVisibleTab(windowId, { format: "png" });
  await setPendingCapture({ kind: "crop", dataUrl: screenshotDataUrl, bounds, capturedAt: Date.now() });
  await openPanel(windowId);
}

async function setPendingCapture(value) {
  await chrome.storage.local.set({ pendingCapture: value });
  chrome.runtime.sendMessage({ type: "PENDING_CAPTURE_READY" }).catch(() => {});
}

async function openPanel(windowId) {
  try {
    await chrome.sidePanel.open({ windowId });
  } catch {
    // Chrome may refuse a programmatic open if user activation has expired.
    // The pending capture remains available when the toolbar button is clicked.
  }
}

function readableError(error) {
  const message = error?.message || String(error);
  if (message.includes("Cannot access")) return "Chrome does not allow extensions on this page. Try a normal website tab.";
  return message;
}
