(() => {
  const existing = document.getElementById("visual-prompt-region-overlay");
  if (existing) existing.remove();

  const overlay = document.createElement("div");
  overlay.id = "visual-prompt-region-overlay";
  Object.assign(overlay.style, {
    position: "fixed",
    inset: "0",
    zIndex: "2147483647",
    cursor: "crosshair",
    background: "rgba(8, 12, 20, .42)",
    userSelect: "none"
  });

  const help = document.createElement("div");
  help.textContent = "Drag to select an area · Esc to cancel";
  Object.assign(help.style, {
    position: "fixed",
    top: "18px",
    left: "50%",
    transform: "translateX(-50%)",
    padding: "10px 16px",
    borderRadius: "999px",
    color: "white",
    background: "rgba(9, 13, 22, .92)",
    font: "600 13px -apple-system, BlinkMacSystemFont, sans-serif",
    boxShadow: "0 8px 30px rgba(0,0,0,.3)"
  });

  const selection = document.createElement("div");
  Object.assign(selection.style, {
    display: "none",
    position: "fixed",
    border: "2px solid #8b5cf6",
    background: "rgba(139, 92, 246, .10)",
    boxShadow: "0 0 0 9999px rgba(8, 12, 20, .62)"
  });

  overlay.append(help, selection);
  document.documentElement.appendChild(overlay);

  let startX = 0;
  let startY = 0;
  let dragging = false;

  overlay.addEventListener("mousedown", (event) => {
    if (event.button !== 0) return;
    dragging = true;
    startX = event.clientX;
    startY = event.clientY;
    selection.style.display = "block";
    update(event.clientX, event.clientY);
  });

  overlay.addEventListener("mousemove", (event) => {
    if (dragging) update(event.clientX, event.clientY);
  });

  overlay.addEventListener("mouseup", async (event) => {
    if (!dragging) return;
    dragging = false;
    const bounds = makeBounds(event.clientX, event.clientY);
    cleanup();
    if (bounds.width < 20 || bounds.height < 20) return;
    await new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve)));
    chrome.runtime.sendMessage({ type: "REGION_SELECTED", bounds });
  });

  document.addEventListener("keydown", onKey, true);

  function onKey(event) {
    if (event.key === "Escape") cleanup();
  }

  function makeBounds(x, y) {
    const left = Math.max(0, Math.min(startX, x));
    const top = Math.max(0, Math.min(startY, y));
    const right = Math.min(innerWidth, Math.max(startX, x));
    const bottom = Math.min(innerHeight, Math.max(startY, y));
    return {
      x: left,
      y: top,
      width: right - left,
      height: bottom - top,
      viewportWidth: innerWidth,
      viewportHeight: innerHeight
    };
  }

  function update(x, y) {
    const bounds = makeBounds(x, y);
    Object.assign(selection.style, {
      left: `${bounds.x}px`,
      top: `${bounds.y}px`,
      width: `${bounds.width}px`,
      height: `${bounds.height}px`
    });
  }

  function cleanup() {
    document.removeEventListener("keydown", onKey, true);
    overlay.remove();
  }
})();
